#ifndef SETIDPOPUP_H
#define SETIDPOPUP_H

#include <gd.h>

namespace gd {
    class TextInputDelegate;

    class SetIDPopup : public FLAlertLayer, public TextInputDelegate {
        // todo
    };
}

#endif
